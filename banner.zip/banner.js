const banner = document.querySelector(".slick-track");
const firstBanner = document.createElement("div");
const lastBanner = document.createElement("div");
const buttons = document.querySelectorAll(".slick-arrow");
const currntCount = document.querySelector(".banner-info-button-current-count");
let count = 1;

firstBanner.innerHTML = `<img src="https://res.cloudinary.com/frientrip/image/upload/ar_5:2,c_fill,dpr_2,f_auto,q_auto,w_930/hb_web_pc_%EA%B0%95%EB%A6%89%EA%B0%88%EB%9E%98_3b5424cdc3d01542842fa5c10e12d63934c77de3ddd669f8b0f2c54ee77bf61b" class="image">`;
lastBanner.innerHTML = `<img src="https://res.cloudinary.com/frientrip/image/upload/ar_5:2,c_fill,dpr_2,f_auto,q_auto,w_930/250312_Web_banner_%E1%84%80%E1%85%B5%E1%84%8C%E1%85%A9%E1%86%AB%E1%84%92%E1%85%AC%E1%84%8B%E1%85%AF%E1%86%AB%E1%84%8B%E1%85%A9%E1%86%AB%E1%84%87%E1%85%A9%E1%84%83%E1%85%B5%E1%86%BC_8abf17e17d5e2015486d1edc78b8538b3a7571c13e9562d419ae05fe5ac16c8f" class="image">`;
firstBanner.classList.add("slick-slide");
lastBanner.classList.add("slick-slide");
banner.appendChild(firstBanner);
banner.prepend(lastBanner);

currntCount.textContent = count;
banner.style.transform = `translate(-768px)`;

const autoSlide = () => {
    count++;
    banner.style.transform = `translate(-${768 * count}px)`;
    banner.style.transition = `transform 0.5s`;

    if (count === 7) {
        setTimeout(() => {
            banner.style.transform = `translate(-768px)`;
            banner.style.transition = `transform 0s`;
        }, 500);
        count = 1;
    }
    currntCount.textContent = count;
};
let autoSlideInterval = setInterval(autoSlide, 1000);
let buttonCheck = false;

buttons.forEach((button) => {
    button.addEventListener("click", (e) => {
        if (buttonCheck) {
            return;
        }
        buttonCheck = true;
        clearInterval(autoSlideInterval);

        const buttonType = button.classList[1];

        if (buttonType.includes("prev")) {
            count--;
            banner.style.transform = `translate(-${768 * count}px)`;
            banner.style.transition = `transform 0.5s`;
            if (count === 0) {
                setTimeout(() => {
                    banner.style.transform = `translate(-4608px)`;
                    banner.style.transition = `transform 0s`;
                }, 500);
                count = 6;
            }
        } else {
            count++;
            banner.style.transform = `translate(-${768 * count}px)`;
            banner.style.transition = `transform 0.5s`;
            if (count === 7) {
                setTimeout(() => {
                    banner.style.transform = `translate(-768px)`;
                    banner.style.transition = `transform 0s`;
                }, 500);
                count = 1;
            }
        }
        currntCount.textContent = count;

        autoSlideInterval = setInterval(autoSlide, 1500);
        setTimeout(() => {
            buttonCheck = false;
        }, 500);
    });
});

// banner 총 너비: 6,144
// banner 하나의 너비: 768
// banner 개수: 6개 + 0, 7

// 0: 0

// 1: 768
// 2: 1536
// 3: 2304
// 4: 3072
// 5: 3840
// 6: 4608

// 7: 5376
