const banner = document.querySelector("div.banner");
const firstBanner = document.createElement("div");
const lastBanner = document.createElement("div");
const arrows = document.querySelectorAll(".arrow");
const strong = document.querySelector(".count strong");
let count = 1;

firstBanner.innerHTML = `<img src="https://img.tumblbug.com/eyJidWNrZXQiOiJ0dW1ibGJ1Zy1pbWctcHJvZCIsImtleSI6Imhlcm9lcy9tYWluX3BjX3BhdHRlcm5fZ2xpdHRpbmcucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjpudWxsLCJoZWlnaHQiOm51bGwsIndpdGhvdXRFbmxhcmdlbWVudCI6dHJ1ZSwiZml0IjpudWxsfSwicm91bmRDcm9wIjpmYWxzZSwicm90YXRlIjpudWxsfX0=">`;
lastBanner.innerHTML = `<img src="https://img.tumblbug.com/eyJidWNrZXQiOiJ0dW1ibGJ1Zy1pbWctcHJvZCIsImtleSI6Imhlcm9lcy9tYWluX3BjX3VuaXpfMTcxNzE3LnBuZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6bnVsbCwiaGVpZ2h0IjpudWxsLCJ3aXRob3V0RW5sYXJnZW1lbnQiOnRydWUsImZpdCI6bnVsbH0sInJvdW5kQ3JvcCI6ZmFsc2UsInJvdGF0ZSI6bnVsbH19">`;
banner.appendChild(firstBanner);
banner.prepend(lastBanner);

banner.style.transform = `translate(-766px)`;

const autoSlide = () => {
    count++;
    banner.style.transform = `translate(-${766 * count}px)`;
    banner.style.transition = `transform 0.5s`;

    if (count === 4) {
        setTimeout(() => {
            banner.style.transform = `translate(-766px)`;
            banner.style.transition = `transform 0s`;
        }, 500);
        count = 1;
    }
    strong.innerHTML = count;
};

let autoSlideInterval = setInterval(autoSlide, 1000);
let arrowCheck = false;

arrows.forEach((arrow) => {
    arrow.addEventListener("click", (e) => {
        if (arrowCheck) {
            return;
        }
        arrowCheck = true;
        clearInterval(autoSlideInterval);

        const arrowType = arrow.classList[1];
        if (arrowType === "left-arrow") {
            count--;
            banner.style.transform = `translate(-${766 * count}px)`;
            banner.style.transition = `transform 0.5s`;

            if (count === 0) {
                setTimeout(() => {
                    banner.style.transform = `translate(-2298px)`;
                    banner.style.transition = `transform 0s`;
                }, 500);
                count = 3;
            }
        } else {
            count++;
            banner.style.transform = `translate(-${766 * count}px)`;
            banner.style.transition = `transform 0.5s`;

            if (count === 4) {
                setTimeout(() => {
                    banner.style.transform = `translate(-766px)`;
                    banner.style.transition = `transform 0s`;
                }, 500);
                count = 1;
            }
        }
        strong.innerHTML = count;

        autoSlideInterval = setInterval(autoSlide, 1000);
        setTimeout(() => {
            arrowCheck = false;
        }, 500);
    });
});
