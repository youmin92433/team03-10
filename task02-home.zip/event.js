const button = document.getElementById("button");

button.addEventListener("click", (e) => {
    const layout = usersLayout();
    userService.getList(layout.showUsers);
});
