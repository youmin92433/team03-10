// 이메일 주소가 .biz로 끝나는 사용자는 글자색을 **파란색(Blue)**으로 표시하세요.
// 그 외의 사용자는 검은색으로 표시하세요. -->
const usersLayout = () => {
    const showUsers = (users) => {
        const tbody = document.querySelector("tbody");

        users = users.slice(0, 10);

        let text = ``;
        users.forEach((user) => {
            const isBiz = user.email.endsWith(".biz");
            const emailClass = isBiz ? "biz-true" : "biz-false";
            text += `
                <tr>
                    <td>${user.name}</td>
                    <td class="${emailClass}">${user.email}</td>
                    <td>${user.address.city}</td>
                </tr>            
            `;
        });

        tbody.innerHTML = text;
    };

    return { showUsers: showUsers };
};
